
# 🚀 Step-by-Step Deployment Guide (Zero Experience Required)

Follow these steps exactly to make your app live and **save your data permanently**.

---

## 🆘 CANNOT FIND THE DOWNLOAD ICON ON MOBILE?
If you don't see the cloud download icon in the top right:
1.  **Rotate your phone** to Landscape (Horizontal) mode.
2.  **Use Desktop Mode**: Tap the three dots in your browser and select "Desktop site".
3.  **USE THE BLUE BANNER**: Click the blue **"Move now"** button at the top of the screen. This is a special tool to move your code to GitHub automatically.

---

## Part 1: Connect to Vercel (FIX DATA ERASING)

1.  **Go to Vercel**: Visit [Vercel.com](https://vercel.com) and sign in.
2.  **Project Settings**: Find your project and click **"Settings"** -> **"Environment Variables"**.
3.  **SET THESE 6 KEYS**:
    Paste these exactly. No spaces, no quotes.

| Vercel "Key" (Top Box) | What it represents |
| :--- | :--- |
| `NEXT_PUBLIC_FIREBASE_API_KEY` | Your `apiKey` from Firebase |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | Your `authDomain` from Firebase |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | Your `projectId` from Firebase |
| `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` | Your `storageBucket` from Firebase |
| `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` | Your `messagingSenderId` from Firebase |
| `NEXT_PUBLIC_FIREBASE_APP_ID` | Your `appId` from Firebase |

---

## 🛑 THE "REDEPLOY" STEP (Mandatory!)
Adding keys does **NOT** fix the site until you redeploy:
1.  Go to the **"Deployments"** tab in Vercel.
2.  Click the **three dots (...)** on the latest deployment.
3.  Click **"Redeploy"**.
4.  **Wait for it to finish.**

---

## Part 2: Ongoing Updates
When we finish a chat, you must:
1.  **Download the zip** (or use "Move now").
2.  **Upload the files** to your GitHub repository.
3.  Vercel will update the site automatically.
